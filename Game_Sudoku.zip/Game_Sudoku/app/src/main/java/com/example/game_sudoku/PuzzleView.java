package com.example.game_sudoku;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Paint.FontMetrics;
import android.graphics.Paint.Style;

import android.os.Bundle;
import android.os.Parcelable;

import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;


public class PuzzleView extends View {


    //定义常字符串
    private static final String SELX = "selX";
    private static final String SELY = "selY";
    private static final String VIEW_STATE = "viewState";
    private static final int ID = 42;


    private float width;    // 定义格子的宽度
    private float height;   // 定义格子的高度
    private int selX;       // 定义选择格子的X坐标
    private int selY;       // 定义选择格子的Y坐标
    private final Rect selRect = new Rect();

    private final Game game;

    //注册构造方法
    public PuzzleView(Context context) {

        super(context);
        this.game = (Game) context;
        setFocusable(true);
        setFocusableInTouchMode(true);

        setId(ID);
    }

    //保存所有的数据，使应用从后台返回时能够显示
    @Override
    protected Parcelable onSaveInstanceState() {
        Parcelable p = super.onSaveInstanceState();

        Bundle bundle = new Bundle();
        bundle.putInt(SELX, selX);
        bundle.putInt(SELY, selY);
        bundle.putParcelable(VIEW_STATE, p);
        return bundle;
    }
    //当该activity没有销毁，重新获得焦点的时候载入保存的数据
    @Override
    protected void onRestoreInstanceState(Parcelable state) {

        Bundle bundle = (Bundle) state;
        select(bundle.getInt(SELX), bundle.getInt(SELY));
        super.onRestoreInstanceState(bundle.getParcelable(VIEW_STATE));
        return;
    }

    //根据设备的不同自动适应高度和宽度
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        width = w / 9f;
        height = h / 9f;
        getRect(selX, selY, selRect);
        super.onSizeChanged(w, h, oldw, oldh);
    }

    //需要重新复写OnDraw方法
    @Override
    protected void onDraw(Canvas canvas) {
        // 画背景
        Paint background = new Paint();
        background.setColor(getResources().getColor(
                R.color.puzzle_background));
        canvas.drawRect(0, 0, getWidth(), getHeight(), background);

        // 定义颜色和划线
        Paint dark = new Paint();
        dark.setColor(getResources().getColor(R.color.puzzle_dark));

        Paint hilite = new Paint();
        hilite.setColor(getResources().getColor(R.color.puzzle_hilite));

        Paint light = new Paint();
        light.setColor(getResources().getColor(R.color.puzzle_light));

        // 定义划线
        for (int i = 0; i < 9; i++) {
            canvas.drawLine(0, i * height, getWidth(), i * height,
                    dark);
            canvas.drawLine(0, i * height + 1, getWidth(), i * height
                    + 1, hilite);
            canvas.drawLine(i * width, 0, i * width, getHeight(),
                    dark);
            canvas.drawLine(i * width + 1, 0, i * width + 1,
                    getHeight(), hilite);
        }

        // 画大的3*3分界线
        for (int i = 0; i < 9; i++) {
            if (i % 3 != 0)
                continue;
            canvas.drawLine(0, i * height, getWidth(), i * height,
                    dark);
            canvas.drawLine(0, i * height + 1, getWidth(), i * height
                    + 1, hilite);
            canvas.drawLine(i * width, 0, i * width, getHeight(), dark);
            canvas.drawLine(i * width + 1, 0, i * width + 1,
                    getHeight(), hilite);
        }

        // 画初始数字
        // 定义数字的颜色和其他特性
        Paint foreground = new Paint();
        foreground.setColor(Color.RED);
        foreground.setStyle(Style.FILL);
        foreground.setTextSize(height * 0.75f);
        foreground.setTextAlign(Paint.Align.CENTER);

        // 使文字居中对齐
        FontMetrics fm = foreground.getFontMetrics();
        // 居中对齐x
        float x = width / 2;
        // 居中对齐y
        float y = height / 2 - (fm.ascent + fm.descent) / 2;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if(!game.getTileString(i,j,game.puzzle).equals("")){
                canvas.drawText(game.getTileString(i, j,game.puzzle), i * width + x, j * height + y, foreground);}
            }
        }

        // 画所填数字
        // 定义数字的颜色和其他特性
        Paint selPaint = new Paint();
        selPaint.setColor(Color.BLACK);
        selPaint.setStyle(Style.FILL);
        selPaint.setTextSize(height * 0.75f);
        selPaint.setTextAlign(Paint.Align.CENTER);


        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if(!game.getTileString(i,j,game.dopuzzle).equals("")){
                    canvas.drawText(game.getTileString(i, j,game.dopuzzle), i * width + x, j * height + y, selPaint);}
            }
        }



        if (Prefs.getHints(getContext())) {
            // 画提示

            // 根据所剩选择数目的多少分别提示不同的颜色,0为无法填充，比较深的绿色表示只剩1步可填，浅绿色表示有2步剩余
            Paint hint = new Paint();
            int c[] = { getResources().getColor(R.color.puzzle_hint_0),
                    getResources().getColor(R.color.puzzle_hint_1),
                    getResources().getColor(R.color.puzzle_hint_2), };
            Rect r = new Rect();
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    int movesleft = 9 - game.getUsedTiles(i, j).length;
                    if (movesleft < c.length) {
                        getRect(i, j, r);
                        hint.setColor(c[movesleft]);
                        canvas.drawRect(r, hint);
                    }
                }
            }

        }


    //将当前选择的块涂色
        Paint selected = new Paint();
        selected.setColor(getResources().getColor(
                R.color.puzzle_selected));
        canvas.drawRect(selRect, selected);
    }
    //注册触摸响应事件
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_DOWN)
            return super.onTouchEvent(event);

        select((int) (event.getX() / width),
                (int) (event.getY() / height));
        game.showKeypadOrError(selX, selY);

        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                select(selX, selY - 1);
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                select(selX, selY + 1);
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                select(selX - 1, selY);
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                select(selX + 1, selY);
                break;
            case KeyEvent.KEYCODE_0:
            case KeyEvent.KEYCODE_SPACE: setSelectedTile(0); break;
            case KeyEvent.KEYCODE_1:     setSelectedTile(1); break;
            case KeyEvent.KEYCODE_2:     setSelectedTile(2); break;
            case KeyEvent.KEYCODE_3:     setSelectedTile(3); break;
            case KeyEvent.KEYCODE_4:     setSelectedTile(4); break;
            case KeyEvent.KEYCODE_5:     setSelectedTile(5); break;
            case KeyEvent.KEYCODE_6:     setSelectedTile(6); break;
            case KeyEvent.KEYCODE_7:     setSelectedTile(7); break;
            case KeyEvent.KEYCODE_8:     setSelectedTile(8); break;
            case KeyEvent.KEYCODE_9:     setSelectedTile(9); break;
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_DPAD_CENTER:
                game.showKeypadOrError(selX, selY);
                break;
            default:
                return super.onKeyDown(keyCode, event);
        }
        return true;
    }



    public void setSelectedTile(int tile) {
        if (game.setTileIfValid(selX, selY, tile)) {
            invalidate();// 刷新显示

            if (game.checkfinished()){
                finishDlg finishDlg = new finishDlg(getContext());
                finishDlg.show();
            }
        }

    }

    private void select(int x, int y) {
        invalidate(selRect);
        selX = Math.min(Math.max(x, 0), 8);
        selY = Math.min(Math.max(y, 0), 8);
        getRect(selX, selY, selRect);
        invalidate(selRect);
    }

    private void getRect(int x, int y, Rect rect) {
        rect.set((int) (x * width), (int) (y * height), (int) (x
                * width + width), (int) (y * height + height));
    }

    // ...
    //设置删除方格
    public void setDeleteTile(){
        game.deleteTile(selX,selY);
        //重绘画布
        invalidate();
    }
}
